package com.example.panaremote

/**
 * Encoder untuk protokol IR aircond Panasonic (frame 27 byte, carrier ~36.7 kHz).
 * Berdasarkan struktur protokol yang digunakan oleh IRremoteESP8266.
 */
class PanasonicAc {

    enum class Mode(val bits: Int, val label: String) {
        AUTO(0x0, "Auto"), DRY(0x2, "Dry"), COOL(0x3, "Cool"), HEAT(0x4, "Heat"), FAN(0x6, "Fan")
    }

    enum class Fan(val bits: Int, val label: String) {
        AUTO(0xA, "Auto"), F1(0x3, "1"), F2(0x4, "2"), F3(0x5, "3"), F4(0x6, "4"), F5(0x7, "5")
    }

    var power = false
    var mode = Mode.COOL
    var temp = 25
    var fan = Fan.AUTO
    var swing = true

    companion object {
        const val CARRIER_HZ = 36700
        private const val HDR_MARK = 3456
        private const val HDR_SPACE = 1728
        private const val BIT_MARK = 432
        private const val ONE_SPACE = 1296
        private const val ZERO_SPACE = 432
        private const val GAP = 10000
        const val MIN_TEMP = 16
        const val MAX_TEMP = 30
    }

    private fun buildState(): IntArray {
        val s = intArrayOf(
            0x02, 0x20, 0xE0, 0x04, 0x00, 0x00, 0x00, 0x06,
            0x02, 0x20, 0xE0, 0x04, 0x00, 0x00, 0x00, 0x80,
            0x00, 0x00, 0x00, 0x06, 0x60, 0x00, 0x00, 0x80,
            0x00, 0x00, 0x00
        )
        s[13] = (mode.bits shl 4) or (if (power) 1 else 0)
        s[14] = temp.coerceIn(MIN_TEMP, MAX_TEMP) shl 1
        s[16] = (fan.bits shl 4) or (if (swing) 0xF else 0x1)
        var sum = 0xF4
        for (i in 0 until 26) sum += s[i]
        s[26] = sum and 0xFF
        return s
    }

    private fun appendSection(out: MutableList<Int>, bytes: IntArray, from: Int, to: Int) {
        out += HDR_MARK
        out += HDR_SPACE
        for (i in from until to) {
            for (b in 0 until 8) { // LSB dulu
                out += BIT_MARK
                out += if ((bytes[i] shr b) and 1 == 1) ONE_SPACE else ZERO_SPACE
            }
        }
        out += BIT_MARK
        out += GAP
    }

    /** Corak mark/space dalam mikrosaat untuk ConsumerIrManager.transmit(). */
    fun pattern(): IntArray {
        val state = buildState()
        val out = ArrayList<Int>(500)
        appendSection(out, state, 0, 8)
        appendSection(out, state, 8, 27)
        return out.toIntArray()
    }
}

package com.example.panaremote

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val ac = PanasonicAc()
    private var ir: ConsumerIrManager? = null

    private lateinit var tempText: TextView
    private lateinit var statusText: TextView
    private lateinit var powerBtn: Button
    private lateinit var modeBtn: Button
    private lateinit var fanBtn: Button
    private lateinit var swingBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        buildUi()
        refresh()
        if (ir?.hasIrEmitter() != true) {
            Toast.makeText(this, "Telefon ini tiada IR blaster", Toast.LENGTH_LONG).show()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }

        root.addView(TextView(this).apply {
            text = "Panasonic AC Remote"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })

        tempText = TextView(this).apply {
            textSize = 64f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(4))
        }
        root.addView(tempText)

        statusText = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        }
        root.addView(statusText)

        root.addView(row(
            btn("Suhu −") { ac.temp = (ac.temp - 1).coerceAtLeast(PanasonicAc.MIN_TEMP); send() },
            btn("Suhu +") { ac.temp = (ac.temp + 1).coerceAtMost(PanasonicAc.MAX_TEMP); send() }
        ))

        powerBtn = btn("Power") { ac.power = !ac.power; send() }
        modeBtn = btn("Mode") {
            val all = PanasonicAc.Mode.values()
            ac.mode = all[(ac.mode.ordinal + 1) % all.size]; send()
        }
        root.addView(row(powerBtn, modeBtn))

        fanBtn = btn("Fan") {
            val all = PanasonicAc.Fan.values()
            ac.fan = all[(ac.fan.ordinal + 1) % all.size]; send()
        }
        swingBtn = btn("Swing") { ac.swing = !ac.swing; send() }
        root.addView(row(fanBtn, swingBtn))

        setContentView(root)
    }

    private fun refresh() {
        tempText.text = "${ac.temp}°C"
        statusText.text = "${if (ac.power) "ON" else "OFF"} • ${ac.mode.label} • Fan ${ac.fan.label} • Swing ${if (ac.swing) "On" else "Off"}"
        powerBtn.text = if (ac.power) "Power: ON" else "Power: OFF"
        modeBtn.text = "Mode: ${ac.mode.label}"
        fanBtn.text = "Fan: ${ac.fan.label}"
        swingBtn.text = "Swing: ${if (ac.swing) "On" else "Off"}"
    }

    private fun send() {
        refresh()
        val mgr = ir
        if (mgr == null || !mgr.hasIrEmitter()) {
            Toast.makeText(this, "Tiada IR blaster", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            mgr.transmit(PanasonicAc.CARRIER_HZ, ac.pattern())
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal hantar: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
